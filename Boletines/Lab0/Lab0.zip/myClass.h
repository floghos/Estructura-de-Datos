class myClass {

  private:
    int n;
    int *arr;

  public:
    myClass(int val);
    void mostrar();
    int suma();

};
